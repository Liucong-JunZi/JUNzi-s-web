---
name: parallel-dev
description: Enable parallel development using Git worktrees and multiple sub-agents. Use this skill when users want to distribute development tasks across multiple teams/modules, need concurrent feature development, or request "parallel development" or "worktree-based development". Follows Microsoft-style code management practices.
---

# Parallel Development with Worktrees

## Overview

Enable parallel development by distributing tasks across multiple Git worktrees, each handled by independent sub-agents. Follows Microsoft-style code management with strict code review, testing requirements, and communication protocols.

## When to Use

- Multiple independent features need concurrent development
- User requests "parallel development" or "divide work across teams"
- Large project with clear module boundaries
- Need isolation between different development streams

## Core Workflow

### Step 1: Analyze and Plan

1. Identify independent modules/features that can be developed in parallel
2. Define module boundaries and responsibilities
3. Create API contracts before development begins (see `references/api-contract-template.md`)
4. Document dependencies between modules

### Step 2: Initialize Worktrees

Run the initialization script from the MAIN worktree:

```bash
# Default: create from 'main' branch
python scripts/init_parallel_dev.py --modules "frontend" "backend" "infra"

# Custom base branch (e.g., develop)
python scripts/init_parallel_dev.py --modules "frontend" "backend" "infra" --base-branch develop
```

This creates:
- `.worktrees/frontend/` - Frontend development worktree
- `.worktrees/backend/` - Backend development worktree
- `.worktrees/infra/` - Infrastructure worktree

Each worktree gets its own branch: `feature/frontend`, `feature/backend`, `feature/infra`

**Communication File**: The script creates `.parallel-dev/communication.md` in the MAIN worktree. All agents read/write to this same file regardless of which worktree they're in.

**Path Reference**: A `.parallel-dev-path` file is created in each worktree pointing to the shared communication file.

### Step 3: Create Development Teams

Spawn sub-agents for each module using your platform's agent coordination tools:

| Agent | Role | Worktree | Responsibilities |
|-------|------|----------|------------------|
| frontend-team | Developer | .worktrees/frontend | UI components, pages, styling |
| backend-team | Developer | .worktrees/backend | API endpoints, business logic |
| infra-team | Developer | .worktrees/infra | Docker, CI/CD, infrastructure |

Each agent should work exclusively in its assigned worktree.

### Step 4: Distribute Tasks

Create and assign tasks to teams using your platform's task management capabilities. Each agent should:
1. Work exclusively in its assigned worktree
2. Check the shared communication file for updates
3. Post progress and blocking issues to communication.md

### Step 5: Communication Protocol

All inter-team communication uses a SHARED file in the MAIN worktree:

**Location**: `<main-worktree>/.parallel-dev/communication.md`

**Path Reference**: Read `.parallel-dev-path` file to find the absolute path.

Use `scripts/communicate.py` to post messages:

```bash
python scripts/communicate.py --from backend-team --to frontend-team --message "API endpoint /api/posts ready"
```

**IMPORTANT**: The communication script always writes to the MAIN worktree's communication.md, regardless of which worktree invokes it.

### Step 6: Progress Synchronization

Run sync from any worktree to check for conflicts:

```bash
python scripts/sync_progress.py
```

This checks for:
- Working tree conflicts (same files modified)
- Branch divergence (many commits ahead of base branch)

### Step 7: Handle Conflicts

When conflicts detected:

1. **File-level conflict**: Both teams modified same file
   - Priority: Backend > Frontend > Infra (or as specified)
   - Losing team rebases and adapts

2. **API contract conflict**:
   - Halt both teams
   - Discuss via communication.md
   - Update contract, both adapt

3. **Logic conflict**:
   - Create integration task
   - Assign to senior reviewer

### Step 8: Integration and Testing

Before merging:

1. Run module tests in each worktree
2. Run integration tests (see `scripts/run_integration_tests.py`)
3. Code review required (see `references/code-review-checklist.md`)
4. Merge in dependency order: Infra → Backend → Frontend

### Step 9: Merge and Cleanup

Merge happens IN THE MAIN WORKTREE:

```bash
# Default: merges into saved base branch (from init --base-branch)
python scripts/merge_worktrees.py --order infra backend frontend

# Explicit target branch
python scripts/merge_worktrees.py --order infra backend frontend --target develop
```

After successful merge:
```bash
python scripts/cleanup_worktrees.py
```

**Safety Guarantees**:
- All merge operations execute in the main worktree
- Cleanup only removes `.worktrees/*` directories
- Main worktree is never affected by cleanup

## Handling Common Issues

### Conflict Resolution Priority

| Scenario | Resolution |
|----------|------------|
| Same file modified | Higher priority team wins, other rebases |
| API signature change | Backend defines, Frontend adapts |
| Database schema change | Infra defines, Backend adapts |
| Type definition conflict | Create shared types in separate file |

### Failure Recovery

If a module fails:
1. Mark task as blocked in your task management system
2. Post to communication.md
3. Other teams continue if not dependent
4. Assign fix task to appropriate team

**⚠️ WARNING**: For rollback scenarios, see `references/edge-cases.md` for proper procedures. Never use destructive git operations without understanding the consequences.

### Dependency Coordination

1. Define interfaces BEFORE implementation
2. Use mock responses during development
3. Contract testing before integration

## Code Standards

Follow standards in `references/microsoft-code-standards.md`:

- All code must have unit tests (>80% coverage)
- PR must pass CI/CD checks
- At least one code review approval required
- No direct commits to main branch
- Meaningful commit messages (conventional commits)

## Technical Details

### Base Branch Persistence

The `--base-branch` specified in `init_parallel_dev.py` is saved to `.parallel-dev/config.json`:
- `sync_progress.py` uses it for divergence detection
- `merge_worktrees.py` uses it as the default merge target
- Override with `--target` flag in merge if needed

### Communication File Location

The shared communication file is ALWAYS in the main worktree:
- Path: `<main-worktree>/.parallel-dev/communication.md`
- Reference: `.parallel-dev-path` file contains the absolute path

This ensures all agents share the same communication channel regardless of their current worktree.

### Merge Operations

All merge operations (`merge_worktrees.py`) execute in the main worktree:
- The script explicitly sets `cwd=<main-worktree>` for all git operations
- Safe to invoke from any worktree

### Cleanup Safety

`cleanup_worktrees.py`:
- Only removes worktrees in `.worktrees/` directory
- Never affects the main worktree
- Archives communication only if cleanup succeeds

### Test Detection

`run_integration_tests.py` detects package managers:
1. `pnpm-lock.yaml` → use `pnpm test`
2. `package-lock.json` → use `npm test`
3. No lock file → check if pnpm available
4. Fallback to `npm test`

## Resources

### scripts/
- `init_parallel_dev.py` - Initialize worktrees and shared communication
- `communicate.py` - Post messages to shared communication file
- `sync_progress.py` - Check for conflicts and divergence
- `run_integration_tests.py` - Run tests in secondary worktrees
- `merge_worktrees.py` - Merge all worktrees in order (in main worktree)
- `cleanup_worktrees.py` - Remove secondary worktrees after merge

### references/
- `microsoft-code-standards.md` - Microsoft coding practices
- `api-contract-template.md` - Template for API contracts
- `code-review-checklist.md` - Code review requirements
- `edge-cases.md` - Handling edge cases (read before using destructive operations)

### assets/
- `pr-template.md` - Pull request template