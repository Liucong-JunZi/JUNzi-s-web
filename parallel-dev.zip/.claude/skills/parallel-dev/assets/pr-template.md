# Pull Request Template

## Description
<!-- Provide a brief description of the changes -->

## Type of Change
- [ ] 🐛 Bug fix (non-breaking change which fixes an issue)
- [ ] ✨ New feature (non-breaking change which adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📚 Documentation update
- [ ] 🔧 Refactoring (no functional changes)
- [ ] 🧹 Chore (maintenance, dependencies, etc.)

## Related Issues
<!-- Link related issues: Closes #123, Relates to #456 -->

## Changes Made
<!-- List the main changes -->
-
-
-

## Testing
<!-- Describe how you tested these changes -->

- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual testing completed

### Test Instructions
<!-- Step-by-step instructions for reviewers to test -->

1.
2.
3.

## Screenshots (if applicable)
<!-- Add screenshots for UI changes -->

| Before | After |
|--------|-------|
| | |

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex logic
- [ ] Documentation updated
- [ ] No new warnings generated
- [ ] Tests pass locally
- [ ] API contract followed (if applicable)
- [ ] Communication posted for breaking changes

## Additional Notes
<!-- Any additional information for reviewers -->

---

## For Reviewers

See [Code Review Checklist](../references/code-review-checklist.md) for review requirements.

**By submitting this PR, I confirm that:**
- I have read and followed the code review guidelines
- I have coordinated with other teams if this affects shared code/APIs