# Handling Edge Cases in Parallel Development

⚠️ **WARNING**: This document contains operations that can cause data loss. Read carefully before executing.

---

## Environment Variable Synchronization

### Problem
Different worktrees may need the same environment variables but could get out of sync.

### Solution
Create `.env.example` in root and copy to each worktree:

```bash
# After creating worktrees
for wt in .worktrees/*; do
  cp .env.example "$wt/.env"
done
```

Add to `init_parallel_dev.py`:
```python
def sync_env_files():
    """Copy .env.example to all worktrees."""
    if os.path.exists(".env.example"):
        for wt in get_worktrees():
            shutil.copy(".env.example", f"{wt}/.env")
```

---

## Dependency Version Conflicts

### Problem
Different worktrees might install different versions of shared dependencies.

### Solution
1. Use lock files (package-lock.json, go.sum, etc.)
2. Create a shared dependencies manifest:

```
# .parallel-dev/dependencies.json
{
  "shared": {
    "typescript": "^5.0.0",
    "react": "^18.0.0"
  }
}
```

3. Check versions during sync:
```python
def check_dependency_versions():
    """Warn if dependency versions differ."""
    pass
```

---

## Database Migration Coordination

### Problem
Parallel development may cause conflicting database migrations.

### Solution
1. Create migrations in order (timestamp-based)
2. Use a migration lock file:

```
# .parallel-dev/migration-lock.json
{
  "locked_by": "backend-team",
  "locked_at": "2024-01-01T10:00:00Z",
  "migration_name": "add_users_table"
}
```

3. Always check lock before creating migration
4. Communicate migration completion

---

## Mock Data Management

### Problem
Frontend needs to develop against APIs that don't exist yet.

### Solution
1. Define API contract first
2. Create mock server:

```typescript
// frontend/src/mocks/handlers.ts
import { rest } from 'msw'

export const handlers = [
  rest.get('/api/posts', (req, res, ctx) => {
    return res(ctx.json({ data: mockPosts }))
  }),
]
```

3. Update mock when API contract changes
4. Remove mocks when real API is ready

---

## Test Data Isolation

### Problem
Parallel teams may need different test data states.

### Solution
1. Use separate test databases per worktree
2. Or use database transactions with rollbacks
3. Or use test fixtures that are reset each run

```yaml
# docker-compose.test.yml
services:
  test-db-frontend:
    image: mysql:8
  test-db-backend:
    image: mysql:8
```

---

## Secret Management

### Problem
Teams need access to secrets but shouldn't commit them.

### Solution
1. Use `.env` files (gitignored)
2. Share secrets via secure channel (not in communication.md)
3. Use secret management service if available

```
# .gitignore
.env
.env.local
.env.*.local
```

---

## Rollback Strategy

⚠️ **WARNING**: The following operations can cause data loss. Use only as a last resort.

### Safe Rollback Approach

1. **Create a safety tag before risky operations:**

```bash
git tag -a "backup-$(date +%Y%m%d-%H%M%S)" -m "Backup before rollback"
```

2. **Use `git revert` instead of `git reset --hard`:**

```bash
# Safe: Creates a new commit that undoes changes
git revert <commit-hash>

# NOT RECOMMENDED: Destroys uncommitted work
# git reset --hard <commit-hash>
```

3. **For worktree-specific rollback:**

```bash
# Checkout the worktree
cd .worktrees/<module>

# Stash any uncommitted work first
git stash push -m "backup before rollback"

# Then revert commits
git revert <commit-hash>
```

### Recovery Points

Create recovery points during development:

```bash
# Create a branch as recovery point
git branch recovery-point-<name>

# Or create a tag
git tag -a "recovery-<name>" -m "Recovery point for <reason>"
```

### If You Must Use Destructive Operations

If `git reset --hard` is absolutely necessary:

1. **ALWAYS** create a backup branch first:
   ```bash
   git branch backup-$(date +%Y%m%d-%H%M%S)
   ```

2. **Verify** what will be lost:
   ```bash
   git status
   git diff
   git log -5
   ```

3. **Then** execute with full awareness of consequences

---

## Documentation Synchronization

### Problem
README, API docs, etc. may diverge across worktrees.

### Solution
1. Keep documentation in one place (root)
2. Or have clear ownership (backend owns API docs)
3. Include doc updates in merge order
4. Review docs during code review

---

## Task Dependency Handling

### Problem
Task B depends on Task A, but assigned to different teams.

### Solution
1. Mark task as blocked in your task management system
2. Track dependencies explicitly
3. Notify when blocking task completes

---

## CI/CD Per Worktree

### Problem
Should each worktree run CI separately?

### Solution
1. Lightweight CI for worktrees (quick checks)
2. Full CI only on merge to main
3. Use CI configuration:

```yaml
# .github/workflows/pr.yml
on:
  pull_request:
    branches: [main, feature/*]
```

4. Skip heavy tests on draft PRs