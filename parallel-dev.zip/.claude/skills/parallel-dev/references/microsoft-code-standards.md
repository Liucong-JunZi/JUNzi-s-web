# Microsoft Code Standards

## Code Review Requirements

### Mandatory Checks
- [ ] Code compiles without errors
- [ ] All unit tests pass
- [ ] Code coverage > 80% for new code
- [ ] No security vulnerabilities detected
- [ ] Documentation updated if API changed
- [ ] No hardcoded secrets or credentials

### Review Process
1. Create PR with descriptive title and body
2. Link related issues
3. Assign at least one reviewer
4. All CI checks must pass
5. Address all review comments
6. Squash commits before merge

## Commit Conventions

### Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code restructuring
- `test`: Adding tests
- `chore`: Maintenance

### Examples
```
feat(api): add user authentication endpoint

- Implement JWT token generation
- Add login/logout routes
- Include refresh token support

Closes #123
```

## Testing Standards

### Unit Tests
- One test file per source file
- Test file naming: `<source>.test.ts` or `<source>_test.go`
- Use descriptive test names
- Follow AAA pattern: Arrange, Act, Assert

### Integration Tests
- Place in `tests/integration/` directory
- Use test database/fixtures
- Clean up after each test
- Test critical user flows

### Coverage Requirements
| Type | Minimum |
|------|---------|
| New features | 80% |
| Bug fixes | 70% |
| Refactoring | Maintain current |

## Security Requirements

### Never Commit
- API keys
- Database credentials
- Private keys
- Passwords
- Personal data

### Use Environment Variables
```bash
# .env (never commit)
DATABASE_URL=postgresql://...
API_KEY=sk-...
JWT_SECRET=...
```

### Validate All Input
- Sanitize user input
- Validate API parameters
- Escape SQL queries (use ORM)
- Prevent XSS attacks

## Documentation Standards

### Code Comments
- Explain "why", not "what"
- Document complex algorithms
- Use JSDoc/GoDoc for public functions

### API Documentation
- Document all endpoints
- Include request/response examples
- Document error codes
- Keep in sync with code