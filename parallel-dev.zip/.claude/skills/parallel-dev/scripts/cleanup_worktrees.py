#!/usr/bin/env python3
"""
Clean up worktrees after successful merge.

IMPORTANT: This script only removes worktrees in <main>/.worktrees/ directory.
The main worktree is NEVER affected.

Usage:
    python cleanup_worktrees.py
"""

import argparse
import os
import sys
from pathlib import Path
from datetime import datetime
import shutil

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import run_command, get_main_worktree, get_secondary_worktrees


def has_uncommitted_changes(worktree_path):
    """Check if worktree has uncommitted changes.

    Ignores .parallel-dev-path since it's a helper file created by init script,
    not actual project work.
    """
    returncode, stdout, _ = run_command(["git", "status", "--porcelain"], cwd=worktree_path)
    if not stdout.strip():
        return False

    # Filter out .parallel-dev-path - it's a helper file we created
    # git status --porcelain format: XY filename (e.g., "?? .parallel-dev-path")
    lines = stdout.strip().split("\n")
    for line in lines:
        if not line.strip():
            continue
        # Extract filename (after the 2-char status + space)
        parts = line[3:] if len(line) > 2 else line
        filename = parts.strip()
        # Only ignore exact match of .parallel-dev-path in root
        if filename != ".parallel-dev-path":
            return True

    return False


def remove_worktree(worktree_path, force=False):
    """Remove a worktree.

    Automatically removes .parallel-dev-path helper file before cleanup
    to avoid blocking the worktree removal.
    """
    print(f"🗑️  Removing worktree: {worktree_path}")

    # Check for uncommitted changes (ignoring .parallel-dev-path)
    if not force and has_uncommitted_changes(worktree_path):
        print(f"⚠️  Worktree has uncommitted changes. Use --force to remove anyway.")
        return False

    # Remove .parallel-dev-path helper file if it exists
    # This file is created by init script and blocks git worktree remove
    helper_file = Path(worktree_path) / ".parallel-dev-path"
    if helper_file.exists():
        helper_file.unlink()
        print(f"   Removed helper file: .parallel-dev-path")

    # Try normal removal first
    returncode, _, stderr = run_command(["git", "worktree", "remove", worktree_path])

    if returncode != 0:
        if force:
            # Only use --force when explicitly requested
            returncode, _, stderr = run_command(["git", "worktree", "remove", "--force", worktree_path])
            if returncode != 0:
                print(f"❌ Failed to remove: {stderr}")
                return False
        else:
            print(f"⚠️  Cannot remove cleanly. Use --force if you're sure.")
            return False

    print(f"✅ Removed: {worktree_path}")
    return True


def delete_branch(branch_name, main_worktree):
    """Delete a merged branch (operates in main worktree).

    Args:
        branch_name: Clean branch name like 'feature/frontend'
        main_worktree: Path to main worktree
    """
    print(f"🗑️  Deleting branch: {branch_name}")

    # Use the clean branch name directly (e.g., "feature/frontend")
    returncode, _, stderr = run_command(["git", "branch", "-d", branch_name], cwd=main_worktree)
    if returncode != 0:
        print(f"⚠️  Could not delete branch (may not be merged): {stderr}")
        return False

    print(f"✅ Deleted branch: {branch_name}")
    return True


def cleanup_communication(main_worktree):
    """Archive and remove communication file (in main worktree)."""
    comm_file = Path(main_worktree) / ".parallel-dev" / "communication.md"

    if comm_file.exists():
        # Archive
        archive_dir = Path(main_worktree) / ".parallel-dev" / "archive"
        archive_dir.mkdir(exist_ok=True)

        archive_name = f"communication_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        shutil.move(str(comm_file), str(archive_dir / archive_name))

        print(f"📦 Archived communication file to {archive_dir / archive_name}")
        return True
    return False


def main():
    parser = argparse.ArgumentParser(
        description="Clean up worktrees (only removes <main>/.worktrees/*, never affects main worktree)"
    )
    parser.add_argument("--keep-branches", action="store_true", help="Keep branches after removing worktrees")
    parser.add_argument("--keep-comm", action="store_true", help="Keep communication file")
    parser.add_argument("--force", action="store_true", help="Force removal even with uncommitted changes")
    args = parser.parse_args()

    # Get main worktree first
    main_wt = get_main_worktree()
    if not main_wt:
        print("❌ Could not determine main worktree")
        sys.exit(1)

    print(f"🔒 Main worktree (protected): {main_wt}\n")

    print("🧹 Cleaning up secondary worktrees...\n")

    # Get secondary worktrees BEFORE cleanup
    worktrees = get_secondary_worktrees()
    total_count = len(worktrees)

    if not worktrees:
        print("⚠️  No secondary worktrees to clean up")
        return

    # Remove worktrees
    removed_wt = []
    skipped_wt = []
    for wt in worktrees:
        if remove_worktree(wt["path"], force=args.force):
            removed_wt.append(wt)
        else:
            skipped_wt.append(wt)
            print(f"⚠️  Skipped: {wt['path']}")

    # Check remaining worktrees after cleanup
    remaining_worktrees = get_secondary_worktrees()

    # Only proceed with branches and communication if:
    # 1. At least one was removed, AND
    # 2. No remaining secondary worktrees (all cleaned)
    if not removed_wt:
        print("\n⚠️  No worktrees were removed. Skipping branch deletion and communication cleanup.")
        print("   Use --force to remove worktrees with uncommitted changes.")
        return

    if remaining_worktrees:
        print(f"\n⚠️  {len(remaining_worktrees)} secondary worktree(s) remain. Skipping communication cleanup.")
        print("   Communication file is kept for remaining agents.")
        # Still delete branches for removed worktrees
        if not args.keep_branches:
            print("\n🗑️  Deleting branches for removed worktrees...\n")
            deleted_branches = 0
            for wt in removed_wt:
                if delete_branch(wt["branch"], main_wt):
                    deleted_branches += 1
            print(f"\n📊 Deleted {deleted_branches}/{len(removed_wt)} branches")
        return

    # All secondary worktrees removed - safe to cleanup everything
    deleted_branches = 0
    failed_branches = []
    if not args.keep_branches:
        print("\n🗑️  Deleting merged branches...\n")
        for wt in removed_wt:
            if delete_branch(wt["branch"], main_wt):
                deleted_branches += 1
            else:
                failed_branches.append(wt["branch"])

    # Only archive communication if all branch deletions succeeded
    # (or --keep-branches was used, meaning no deletion attempted)
    if not args.keep_comm:
        if failed_branches:
            print(f"\n⚠️  Skipping communication archive - {len(failed_branches)} branch(es) not fully merged:")
            for branch in failed_branches:
                print(f"   - {branch}")
            print("   Complete the merge and run cleanup again to archive the communication file.")
        else:
            cleanup_communication(main_wt)

    # Summary
    print(f"\n📊 Cleanup Summary:\n")
    print(f"  🗑️  Removed {len(removed_wt)} secondary worktrees")
    print(f"  🔒 Main worktree: unchanged")
    if not args.keep_branches:
        print(f"  🗑️  Deleted {deleted_branches}/{len(removed_wt)} branches")
        if failed_branches:
            print(f"  ⚠️  {len(failed_branches)} branch(es) not merged: {', '.join(failed_branches)}")
    if not args.keep_comm and not failed_branches:
        print(f"  📦 Archived communication file")

    print("\n✅ Cleanup complete!")


if __name__ == "__main__":
    main()
