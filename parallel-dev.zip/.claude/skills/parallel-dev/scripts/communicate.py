#!/usr/bin/env python3
"""
Post messages to shared communication file.

IMPORTANT: The communication file is always in the MAIN worktree,
not the current worktree. This ensures all agents share the same file.

Usage:
    python communicate.py --from backend-team --to frontend-team --message "API ready"
"""

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import get_communication_file


def post_message(from_team, to_team, message, action_items=None):
    """Post a message to the shared communication file."""
    comm_file = get_communication_file()

    if not comm_file:
        print("❌ Communication file not found.")
        print("   Run init_parallel_dev.py first, or ensure you're in a git repo with worktrees.")
        return False

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    msg_block = f"""
## [{timestamp}] From: {from_team} → To: {to_team}

### Message
{message}
"""

    if action_items:
        msg_block += "\n### Action Required\n"
        for item in action_items:
            msg_block += f"- [ ] {item}\n"

    msg_block += "\n---\n"

    # Append to file (always in main worktree)
    with open(comm_file, "a") as f:
        f.write(msg_block)

    print(f"✅ Message posted: {from_team} → {to_team}")
    print(f"   File: {comm_file}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Post message to shared communication file")
    parser.add_argument("--from", dest="from_team", required=True, help="Sender team name")
    parser.add_argument("--to", dest="to_team", required=True, help="Recipient team name")
    parser.add_argument("--message", required=True, help="Message content")
    parser.add_argument("--action", nargs="*", help="Action items")
    args = parser.parse_args()

    post_message(args.from_team, args.to_team, args.message, args.action)


if __name__ == "__main__":
    main()
