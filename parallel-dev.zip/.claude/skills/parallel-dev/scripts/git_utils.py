"""
Git worktree utilities for parallel development.

This module provides shared parsing functions to ensure consistent
branch name handling across all scripts.
"""

import subprocess
import shlex
import json
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output.

    Uses shell=False for safety (no shell injection, proper path handling).
    Accepts cmd as either a string (will be parsed) or a list.

    Returns:
        (returncode, stdout, stderr)
        On FileNotFoundError, returns (-1, "", "command not found: <cmd>")
    """
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)

    try:
        result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except FileNotFoundError:
        return -1, "", f"command not found: {cmd[0] if cmd else 'unknown'}"
    except Exception as e:
        return -1, "", str(e)


def get_main_worktree():
    """Get the primary/main worktree path (absolute).

    Returns the first worktree listed by git, which is always the main worktree.
    """
    returncode, stdout, _ = run_command(["git", "worktree", "list", "--porcelain"])
    if returncode != 0:
        return None

    lines = stdout.split("\n")
    for line in lines:
        if line.startswith("worktree "):
            return str(Path(line.replace("worktree ", "")).resolve())
    return None


def parse_branch_name(porcelain_branch):
    """Parse branch name from git worktree porcelain output.

    Git porcelain returns: refs/heads/feature/frontend
    This function converts to: feature/frontend

    Args:
        porcelain_branch: Raw branch string from git porcelain output

    Returns:
        Clean branch name like 'feature/frontend' or 'main'
    """
    if not porcelain_branch:
        return None

    # Remove refs/heads/ prefix if present
    prefix = "refs/heads/"
    if porcelain_branch.startswith(prefix):
        return porcelain_branch[len(prefix):]

    return porcelain_branch


def parse_module_name(porcelain_branch):
    """Parse module name from git worktree porcelain output.

    For branches like 'feature/frontend', returns 'frontend'.
    For main/master branches, returns None.

    Args:
        porcelain_branch: Raw branch string from git porcelain output

    Returns:
        Module name like 'frontend', 'backend', 'infra', or None for main branch
    """
    branch = parse_branch_name(porcelain_branch)
    if not branch:
        return None

    # Check if it's a feature branch
    prefix = "feature/"
    if branch.startswith(prefix):
        return branch[len(prefix):]

    # Not a feature branch (main, master, etc.)
    return None


def get_secondary_worktrees():
    """Get list of worktrees in <main>/.worktrees/ directory.

    IMPORTANT: Only returns worktrees that are direct children of
    <main-worktree>/.worktrees/, not any path containing ".worktrees".

    Returns:
        List of dicts with 'path', 'branch', 'module' keys
        Example: [{'path': '.worktrees/frontend', 'branch': 'feature/frontend', 'module': 'frontend'}]
    """
    main_wt = get_main_worktree()
    if not main_wt:
        return []

    returncode, stdout, _ = run_command(["git", "worktree", "list", "--porcelain"])
    if returncode != 0:
        return []

    # Expected secondary worktree directory
    expected_parent = Path(main_wt) / ".worktrees"

    worktrees = []
    lines = stdout.split("\n")
    current_wt = None
    current_branch = None

    for line in lines:
        if line.startswith("worktree "):
            current_wt = line.replace("worktree ", "")
        elif line.startswith("branch "):
            current_branch = line.replace("branch ", "")
        elif line == "" and current_wt and current_branch:
            # End of record - process
            wt_path = Path(current_wt).resolve()

            # Only include if parent is exactly <main>/.worktrees/
            if wt_path.parent.resolve() == expected_parent.resolve():
                branch = parse_branch_name(current_branch)
                module = parse_module_name(current_branch)
                if module:  # Only include feature branches
                    worktrees.append({
                        "path": str(wt_path),
                        "branch": branch,  # e.g., "feature/frontend"
                        "module": module   # e.g., "frontend"
                    })
            current_wt = None
            current_branch = None

    # Handle last entry if no trailing newline
    if current_wt and current_branch:
        wt_path = Path(current_wt).resolve()
        if wt_path.parent.resolve() == expected_parent.resolve():
            branch = parse_branch_name(current_branch)
            module = parse_module_name(current_branch)
            if module:
                worktrees.append({
                    "path": str(wt_path),
                    "branch": branch,
                    "module": module
                })

    return worktrees


def get_communication_file():
    """Get the path to the shared communication file.

    Returns path in MAIN worktree's .parallel-dev directory.
    """
    # Try reading .parallel-dev-path first
    path_file = Path(".parallel-dev-path")
    if path_file.exists():
        comm_path = Path(path_file.read_text().strip())
        if comm_path.exists():
            return comm_path

    # Fallback: find main worktree
    main_wt = get_main_worktree()
    if main_wt:
        comm_file = Path(main_wt) / ".parallel-dev" / "communication.md"
        if comm_file.exists():
            return comm_file

    return None


def get_base_branch():
    """Get the base branch from saved config.

    Returns the base branch name (e.g., 'main', 'develop') or 'main' as default.
    """
    main_wt = get_main_worktree()
    if main_wt:
        config_file = Path(main_wt) / ".parallel-dev" / "config.json"
        if config_file.exists():
            try:
                config = json.loads(config_file.read_text())
                return config.get("base_branch", "main")
            except (json.JSONDecodeError, KeyError):
                pass
    return "main"