#!/usr/bin/env python3
"""
Initialize parallel development worktrees.

IMPORTANT: All worktrees are created in <main>/.worktrees/ directory,
regardless of where this script is invoked from.

Usage:
    python init_parallel_dev.py --modules "frontend" "backend" "infra"
"""

import argparse
import os
import sys
from pathlib import Path

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import run_command, get_main_worktree


def create_worktree(main_worktree, module_name, base_branch="main"):
    """Create a worktree for a module.

    IMPORTANT: Always creates under <main_worktree>/.worktrees/<module>/
    to ensure consistency with other scripts that only recognize this location.

    Args:
        main_worktree: Absolute path to main worktree
        module_name: Name of the module (e.g., 'frontend')
        base_branch: Base branch to create from
    """
    # Use absolute path under main worktree
    worktree_path = str(Path(main_worktree) / ".worktrees" / module_name)
    branch_name = f"feature/{module_name}"

    # Check if worktree already exists
    if os.path.exists(worktree_path):
        print(f"⚠️  Worktree already exists: {worktree_path}")
        return False

    # Create worktree with new branch (using list form for safety)
    cmd = ["git", "worktree", "add", "-b", branch_name, worktree_path, base_branch]
    returncode, stdout, stderr = run_command(cmd)

    if returncode != 0:
        print(f"❌ Failed to create worktree: {stderr}")
        return False

    print(f"✅ Created worktree: {worktree_path} (branch: {branch_name})")
    return True


def save_base_branch(main_worktree, base_branch):
    """Save the base branch to a config file for other scripts to use.

    Args:
        main_worktree: Absolute path to main worktree
        base_branch: Base branch name (e.g., 'main', 'develop')
    """
    config_dir = Path(main_worktree) / ".parallel-dev"
    config_dir.mkdir(exist_ok=True)

    config_file = config_dir / "config.json"
    import json
    config = {"base_branch": base_branch}
    config_file.write_text(json.dumps(config, indent=2))
    print(f"✅ Saved base branch config: {base_branch}")


def create_communication_file(main_worktree, modules=None):
    """Create shared communication file in the MAIN worktree.

    IMPORTANT: The communication file must be in the main worktree
    so all agents can access it regardless of which worktree they're in.

    Args:
        main_worktree: Absolute path to main worktree
        modules: List of module names to create path references in their worktrees
    """
    # Always use main worktree's .parallel-dev directory
    comm_dir = Path(main_worktree) / ".parallel-dev"
    comm_dir.mkdir(exist_ok=True)

    comm_file = comm_dir / "communication.md"
    if not comm_file.exists():
        comm_file.write_text(f"""# Parallel Development Communication

This file is shared across all worktrees.
Location: {comm_file}

---

## Communication Log

""")
        print(f"✅ Created communication file: {comm_file}")
    else:
        print(f"⚠️  Communication file already exists: {comm_file}")

    # Create .parallel-dev-path in main worktree root
    link_file = Path(main_worktree) / ".parallel-dev-path"
    link_file.write_text(str(comm_file))
    print(f"✅ Created path reference: {link_file} -> {comm_file}")

    # Create .parallel-dev-path in each secondary worktree for agent convenience
    if modules:
        for module_name in modules:
            wt_link = Path(main_worktree) / ".worktrees" / module_name / ".parallel-dev-path"
            if wt_link.parent.exists():
                wt_link.write_text(str(comm_file))
                print(f"✅ Created path reference in .worktrees/{module_name}/")


def main():
    parser = argparse.ArgumentParser(description="Initialize parallel development worktrees")
    parser.add_argument("--modules", nargs="+", required=True, help="Module names to create worktrees for")
    parser.add_argument("--base-branch", default="main", help="Base branch to create from")
    args = parser.parse_args()

    # Check if we're in a git repo
    returncode, _, _ = run_command(["git", "rev-parse", "--git-dir"])
    if returncode != 0:
        print("❌ Not in a git repository")
        sys.exit(1)

    # Get main worktree for reference (absolute path)
    main_wt = get_main_worktree()
    if not main_wt:
        print("❌ Could not determine main worktree")
        sys.exit(1)

    print(f"📍 Main worktree: {main_wt}")
    print(f"📍 All worktrees will be created under: {main_wt}/.worktrees/\n")

    # Create worktrees - ALWAYS under main worktree
    print(f"🚀 Initializing parallel development for modules: {', '.join(args.modules)}\n")

    success_count = 0
    for module in args.modules:
        if create_worktree(main_wt, module, args.base_branch):
            success_count += 1

    # Create communication file IN MAIN WORKTREE
    create_communication_file(main_wt, args.modules)

    # Save base branch for other scripts
    save_base_branch(main_wt, args.base_branch)

    # Summary
    print(f"\n📊 Summary: {success_count}/{len(args.modules)} worktrees created")

    # List worktrees with output
    print("\n📁 Active worktrees:")
    returncode, stdout, _ = run_command(["git", "worktree", "list"])
    if returncode == 0 and stdout:
        for line in stdout.split("\n"):
            if line.strip():
                print(f"   {line}")

    # Platform-agnostic next steps
    print("\n📝 Next steps:")
    print("   1. Spawn agents for each worktree (use your platform's agent tools)")
    print("   2. Distribute tasks to teams")
    print("   3. Use communication.md for inter-team messaging")
    print("      - Path is stored in .parallel-dev-path")
    print("   4. Run sync_progress.py to check for conflicts")


if __name__ == "__main__":
    main()