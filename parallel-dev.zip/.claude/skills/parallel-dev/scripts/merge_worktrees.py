#!/usr/bin/env python3
"""
Merge worktrees in specified order.

IMPORTANT: Merge operations ALWAYS happen in the MAIN worktree,
regardless of where this script is invoked from.

Usage:
    python merge_worktrees.py --order infra backend frontend
"""

import argparse
import os
import sys
from pathlib import Path

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import run_command, get_main_worktree, get_secondary_worktrees, get_base_branch


def remove_helper_file(main_worktree):
    """Remove .parallel-dev-path helper file before merge to avoid conflict.

    This file is created by init_parallel_dev.py and exists in both main worktree
    and feature branches. Git refuses to merge when an untracked file would be
    overwritten, so we remove it before merging.
    """
    helper_file = Path(main_worktree) / ".parallel-dev-path"
    if helper_file.exists():
        helper_file.unlink()
        print(f"   Removed helper file: .parallel-dev-path")


def merge_branch(branch_name, target_branch, main_worktree):
    """Merge a branch into target. ALWAYS operates in main worktree."""
    print(f"\n🔀 Merging {branch_name} into {target_branch}...")

    # Checkout target IN MAIN WORKTREE
    returncode, _, stderr = run_command(["git", "checkout", target_branch], cwd=main_worktree)
    if returncode != 0:
        print(f"❌ Failed to checkout {target_branch}: {stderr}")
        return False

    # Remove helper file to avoid "untracked file would be overwritten" error
    remove_helper_file(main_worktree)

    # Merge IN MAIN WORKTREE
    returncode, _, stderr = run_command(
        ["git", "merge", branch_name, "--no-ff"],
        cwd=main_worktree
    )
    if returncode != 0:
        print(f"❌ Merge failed: {stderr}")
        print("💡 Resolve conflicts manually in main worktree and commit")
        return False

    print(f"✅ Merged {branch_name}")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Merge secondary worktrees in order (always merges in main worktree)"
    )
    parser.add_argument("--order", nargs="+", required=True, help="Merge order (module names)")
    parser.add_argument("--target", default=None, help="Target branch to merge into (default: saved base branch or 'main')")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be merged")
    args = parser.parse_args()

    # Determine target branch: explicit arg > saved config > 'main'
    target_branch = args.target if args.target else get_base_branch()

    # Get main worktree FIRST (absolute path)
    main_wt = get_main_worktree()
    if not main_wt:
        print("❌ Could not determine main worktree")
        sys.exit(1)

    print(f"🚀 Merging worktrees in order: {' → '.join(args.order)}")
    print(f"🎯 Target branch: {target_branch}")
    print(f"📍 All merges will happen in: {main_wt}\n")

    # Get secondary worktrees
    worktrees = get_secondary_worktrees()

    # Build map: module name -> worktree info
    wt_map = {wt["module"]: wt for wt in worktrees}

    # Check for missing modules BEFORE any merge
    missing_modules = [m for m in args.order if m not in wt_map]
    if missing_modules:
        print(f"❌ Missing worktrees for modules: {', '.join(missing_modules)}")
        print(f"   Available modules: {', '.join(wt_map.keys()) if wt_map else 'none'}")
        print("\n💡 Ensure all modules are initialized before merge")
        sys.exit(1)

    if args.dry_run:
        print("Dry run - would merge:\n")
        for module in args.order:
            print(f"  {module} (branch: {wt_map[module]['branch']})")
        return

    # Merge in order - ALL OPERATIONS IN MAIN WORKTREE
    merged = []
    failed = []

    for module in args.order:
        branch = wt_map[module]["branch"]  # e.g., "feature/frontend"
        if merge_branch(branch, target_branch, main_wt):
            merged.append(module)
        else:
            failed.append(module)
            break  # Stop on first failure

    # Summary
    print(f"\n📊 Merge Summary:\n")
    print(f"  ✅ Merged: {', '.join(merged) if merged else 'none'}")
    print(f"  ❌ Failed: {', '.join(failed) if failed else 'none'}")

    if failed:
        print("\n💡 Fix merge conflicts in main worktree and retry")
        sys.exit(1)
    else:
        print("\n✅ All branches merged successfully!")
        print("💡 Run cleanup_worktrees.py to remove secondary worktrees")


if __name__ == "__main__":
    main()
