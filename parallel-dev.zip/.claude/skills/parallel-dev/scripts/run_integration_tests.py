#!/usr/bin/env python3
"""
Run integration tests across all secondary worktrees (excludes main worktree).

Usage:
    python run_integration_tests.py
"""

import argparse
import os
import sys
from pathlib import Path

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import run_command, get_main_worktree, get_secondary_worktrees


def detect_js_test_command(worktree_path):
    """Detect which package manager and test command to use for JS projects.

    Priority:
    1. pnpm if pnpm-lock.yaml exists → "pnpm test"
    2. npm if package-lock.json exists → "npm test"
    3. pnpm if pnpm is available and only package.json exists → "pnpm test"
    4. npm as fallback → "npm test"

    Returns the full test command as list, or None if not a JS project.
    """
    has_package_json = os.path.exists(os.path.join(worktree_path, "package.json"))
    has_pnpm_lock = os.path.exists(os.path.join(worktree_path, "pnpm-lock.yaml"))
    has_npm_lock = os.path.exists(os.path.join(worktree_path, "package-lock.json"))

    if not has_package_json:
        return None

    if has_pnpm_lock:
        return ["pnpm", "test"]
    if has_npm_lock:
        return ["npm", "test"]

    # No lock file - check if pnpm is available
    returncode, _, _ = run_command(["command", "-v", "pnpm"])
    if returncode == 0:
        return ["pnpm", "test"]

    return ["npm", "test"]


def run_module_tests(worktree_path, module_name):
    """Run tests for a specific module."""
    print(f"\n🧪 Running tests for: {module_name}")
    print(f"   Path: {worktree_path}\n")

    # Check for JS/TS project first
    js_test_cmd = detect_js_test_command(worktree_path)
    if js_test_cmd:
        print(f"   Running: {' '.join(js_test_cmd)}")
        returncode, stdout, stderr = run_command(js_test_cmd, cwd=worktree_path)
        if returncode == 0:
            print(f"   ✅ Tests passed")
            return True
        elif returncode == -1:  # command not found
            print(f"   ❌ Tool not found: {js_test_cmd[0]}")
            return False
        else:
            print(f"   ❌ Tests failed")
            if stderr:
                print(stderr)
            return False

    # Non-JS test frameworks
    test_configs = [
        ("go.mod", ["go", "test", "./..."]),
        ("requirements.txt", ["pytest"]),
        ("pyproject.toml", ["pytest"]),
        ("Cargo.toml", ["cargo", "test"]),
    ]

    for indicator, test_cmd in test_configs:
        if os.path.exists(os.path.join(worktree_path, indicator)):
            print(f"   Running: {' '.join(test_cmd)}")
            returncode, stdout, stderr = run_command(test_cmd, cwd=worktree_path)

            if returncode == 0:
                print(f"   ✅ Tests passed")
                return True
            elif returncode == -1:  # command not found
                print(f"   ❌ Tool not found: {test_cmd[0]}")
                print(f"      Install {test_cmd[0]} to run tests for this module")
                return False
            else:
                print(f"   ❌ Tests failed")
                if stderr:
                    print(stderr)
                return False

    print(f"   ⚠️  No test framework detected")
    return None


def run_integration_tests(main_worktree):
    """Run integration tests in main worktree after merging."""
    print("\n🔗 Running integration tests...\n")

    # Check for integration test file in main worktree
    integration_test = Path(main_worktree) / "tests" / "integration"
    if integration_test.exists():
        returncode, stdout, stderr = run_command(
            ["pytest", "tests/integration", "-v"],
            cwd=main_worktree
        )
        if returncode == 0:
            print("✅ Integration tests passed")
            return True
        elif returncode == -1:  # command not found
            print("❌ pytest not found")
            print("   Install pytest to run integration tests")
            return False
        else:
            print("❌ Integration tests failed")
            if stderr:
                print(stderr)
            return False
    else:
        print("⚠️  No integration tests found")
        return None


def main():
    parser = argparse.ArgumentParser(
        description="Run tests in secondary worktrees (excludes main worktree)"
    )
    parser.add_argument("--skip-unit", action="store_true", help="Skip unit tests")
    args = parser.parse_args()

    print("🚀 Running test suite...\n")

    # Get main worktree FIRST
    main_wt = get_main_worktree()
    if not main_wt:
        print("❌ Could not determine main worktree")
        sys.exit(1)

    print(f"📍 Main worktree: {main_wt}\n")

    # Get only secondary worktrees
    worktrees = get_secondary_worktrees()

    # Run module tests (skip if no secondary worktrees or --skip-unit)
    results = {}
    if worktrees and not args.skip_unit:
        print(f"📁 Testing {len(worktrees)} module worktrees\n")
        for wt in worktrees:
            result = run_module_tests(wt["path"], wt["module"])
            results[wt["module"]] = result
    elif not worktrees:
        print("⚠️  No secondary worktrees found - running integration tests only\n")
    elif args.skip_unit:
        print("⏭️  Skipping unit tests (--skip-unit)\n")

    # Summary for module tests
    if results:
        print("\n📊 Unit Test Summary:\n")
        for module, result in results.items():
            status = "✅" if result else ("⚠️" if result is None else "❌")
            print(f"  {status} {module}")

    # Run integration tests IN MAIN WORKTREE
    integration_result = run_integration_tests(main_wt)

    # Overall status
    all_passed = all(r in [True, None] for r in results.values()) and integration_result in [True, None]

    if all_passed:
        print("\n✅ All tests passed! Ready for merge.")
    else:
        print("\n❌ Some tests failed. Fix before merging.")
        sys.exit(1)


if __name__ == "__main__":
    main()