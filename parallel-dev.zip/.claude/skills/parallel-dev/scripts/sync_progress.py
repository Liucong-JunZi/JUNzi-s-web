#!/usr/bin/env python3
"""
Check for potential conflicts and sync status across worktrees.

This script detects:
- Uncommitted file overlaps (immediate conflict risk)
- Divergent branches (potential merge conflicts)

Usage:
    python sync_progress.py
"""

import os
import sys

# Import shared utilities
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from git_utils import run_command, get_main_worktree, get_secondary_worktrees, get_base_branch


def get_branch_status(worktree_path):
    """Get branch and commit info for a worktree."""
    returncode, branch, _ = run_command(["git", "branch", "--show-current"], cwd=worktree_path)
    returncode, commits, _ = run_command(["git", "log", "--oneline", "-5"], cwd=worktree_path)
    returncode, ahead, _ = run_command(
        ["git", "rev-list", "--count", "HEAD", "^origin/HEAD"],
        cwd=worktree_path
    )
    # Fallback if origin/HEAD doesn't exist
    if returncode != 0:
        ahead = "0"

    return {
        "path": worktree_path,
        "branch": branch,
        "recent_commits": commits.split("\n") if commits else [],
        "commits_ahead": int(ahead) if ahead.isdigit() else 0
    }


def check_working_tree_conflicts():
    """Check for overlapping modified or untracked files in working trees."""
    conflicts = []

    worktrees = get_secondary_worktrees()
    modified_files = {}

    for wt in worktrees:
        # Get tracked file changes
        returncode, stdout, _ = run_command(
            ["git", "diff", "--name-only", "HEAD"],
            cwd=wt["path"]
        )
        tracked_files = set(stdout.split("\n")) if stdout else set()

        # Get untracked files (including newly created)
        returncode, stdout, _ = run_command(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=wt["path"]
        )
        untracked_files = set(stdout.split("\n")) if stdout else set()

        # Combine both, filter empty strings and helper file
        all_changed = {f for f in (tracked_files | untracked_files) if f.strip()}
        # Ignore .parallel-dev-path helper file created by init script
        all_changed.discard(".parallel-dev-path")
        if all_changed:
            modified_files[wt["path"]] = all_changed

    # Check for overlapping modified files
    wt_list = list(modified_files.keys())
    for i, wt1 in enumerate(wt_list):
        for wt2 in wt_list[i+1:]:
            overlap = modified_files[wt1] & modified_files[wt2]
            if overlap:
                conflicts.append({
                    "type": "working_tree_overlap",
                    "worktree1": wt1,
                    "worktree2": wt2,
                    "files": overlap
                })

    return conflicts


def check_branch_divergence(base_branch):
    """Check for potential merge conflicts from divergent branches.

    Args:
        base_branch: The base branch to compare against (e.g., 'main', 'develop')
    """
    risks = []

    worktrees = get_secondary_worktrees()

    for wt in worktrees:
        # Check commits ahead of base branch
        returncode, stdout, _ = run_command(
            ["git", "log", "--oneline", f"{base_branch}..HEAD"],
            cwd=wt["path"]
        )
        if returncode == 0 and stdout:
            commits = stdout.strip().split("\n")
            if len(commits) > 5:
                risks.append({
                    "type": "branch_divergence",
                    "worktree": wt["path"],
                    "branch": wt["branch"],
                    "commits_ahead": len(commits),
                    "note": f"Branch has {len(commits)} commits ahead of {base_branch} - consider syncing"
                })

    return risks


def main():
    print("🔄 Checking worktree sync status...\n")

    # Get main worktree
    main_wt = get_main_worktree()

    # Get secondary worktrees
    worktrees = get_secondary_worktrees()

    if not worktrees:
        print("⚠️  No secondary worktrees found")
        print("   Run init_parallel_dev.py first to create worktrees")
        return

    print("📁 Worktree Status:\n")

    if main_wt:
        print(f"  main (main worktree)")
        print(f"    Path: {main_wt}")
        print()

    for wt in worktrees:
        status = get_branch_status(wt["path"])
        print(f"  {wt['branch']} (module: {wt['module']})")
        print(f"    Path: {status['path']}")
        if status['recent_commits']:
            print(f"    Recent: {status['recent_commits'][0]}")
        if status['commits_ahead'] > 0:
            print(f"    Ahead: {status['commits_ahead']} commits")
        print()

    # Check for working tree conflicts
    print("🔍 Checking for working tree conflicts...\n")
    conflicts = check_working_tree_conflicts()

    if conflicts:
        print("⚠️  Working tree conflicts detected (same files modified):\n")
        for conflict in conflicts:
            print(f"  {conflict['worktree1']} ↔ {conflict['worktree2']}")
            for f in conflict['files']:
                print(f"    - {f}")
            print()
    else:
        print("✅ No working tree conflicts")

    # Check for branch divergence
    print("\n🔍 Checking for branch divergence...\n")
    base_branch = get_base_branch()
    risks = check_branch_divergence(base_branch)

    if risks:
        print("⚠️  Branch divergence detected:\n")
        for risk in risks:
            print(f"  {risk['branch']}: {risk['note']}")
        print()
    else:
        print("✅ No significant branch divergence")

    print("\n💡 Recommendations:")
    print("  - Review communication.md for pending messages")
    print("  - Run integration tests before merge")
    print("  - Coordinate API changes with dependent teams")
    print("  - For branches with many commits, consider rebasing")


if __name__ == "__main__":
    main()
