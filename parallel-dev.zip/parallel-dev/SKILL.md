---
name: parallel-dev
description: Enable parallel development using Git worktrees and multiple sub-agents. Use this skill when users want to distribute development tasks across multiple teams/modules, need concurrent feature development, or request "parallel development" or "worktree-based development". Follows Microsoft-style code management practices.
---

# Parallel Development with Worktrees

## Overview

Enable parallel development by distributing tasks across multiple Git worktrees, each handled by independent sub-agents. Follows Microsoft-style code management with strict code review, testing requirements, and communication protocols.

## When to Use

- Multiple independent features need concurrent development
- User requests "parallel development" or "divide work across teams"
- Large project with clear module boundaries
- Need isolation between different development streams

## Core Workflow

### Step 1: Analyze and Plan

1. Identify independent modules/features that can be developed in parallel
2. Define module boundaries and responsibilities
3. Create API contracts before development begins (see `references/api-contract-template.md`)
4. Document dependencies between modules

### Step 2: Initialize Worktrees

Run the initialization script to create worktrees for each module:

```bash
python scripts/init_parallel_dev.py --modules "frontend" "backend" "infra"
```

This creates:
- `.worktrees/frontend/` - Frontend development worktree
- `.worktrees/backend/` - Backend development worktree
- `.worktrees/infra/` - Infrastructure worktree

Each worktree gets its own branch: `feature/frontend`, `feature/backend`, `feature/infra`

### Step 3: Create Development Teams

Create a team with sub-agents for each module:

```
TeamCreate({
  team_name: "parallel-dev",
  description: "Parallel development team"
})
```

Then spawn sub-agents:

| Agent | Role | Worktree | Responsibilities |
|-------|------|----------|------------------|
| frontend-team | Developer | .worktrees/frontend | UI components, pages, styling |
| backend-team | Developer | .worktrees/backend | API endpoints, business logic |
| infra-team | Developer | .worktrees/infra | Docker, CI/CD, infrastructure |

### Step 4: Distribute Tasks

Create tasks and assign to teams using TaskUpdate:

```
TaskCreate({ subject: "Implement blog page", description: "..." })
TaskUpdate({ owner: "frontend-team" })
```

### Step 5: Communication Protocol

All inter-team communication goes through a shared file:

**Location**: `.parallel-dev/communication.md`

**Format**:
```markdown
## [TIMESTAMP] From: [team] To: [team]

### Message
[Content]

### Action Required
- [ ] [Action item]
```

Use `scripts/communicate.py` to post messages:

```bash
python scripts/communicate.py --from backend-team --to frontend-team --message "API endpoint /api/posts ready"
```

### Step 6: Progress Synchronization

Sync progress every N completed tasks or when:
- API contract changes
- Shared types/interfaces modified
- Dependencies updated

Run sync script:

```bash
python scripts/sync_progress.py
```

### Step 7: Handle Conflicts

When conflicts detected:

1. **File-level conflict**: Both teams modified same file
   - Priority: Backend > Frontend > Infra (or as specified)
   - Losing team rebases and adapts

2. **API contract conflict**:
   - Halt both teams
   - Discuss via communication.md
   - Update contract, both adapt

3. **Logic conflict**:
   - Create integration task
   - Assign to senior reviewer

### Step 8: Integration and Testing

Before merging:

1. Run module tests in each worktree
2. Run integration tests (see `scripts/run_integration_tests.py`)
3. Code review required (see `references/code-review-checklist.md`)
4. Merge in dependency order: Infra → Backend → Frontend

### Step 9: Merge and Cleanup

```bash
python scripts/merge_worktrees.py --order infra backend frontend
```

After successful merge:
```bash
python scripts/cleanup_worktrees.py
```

## Handling Common Issues

### Conflict Resolution Priority

| Scenario | Resolution |
|----------|------------|
| Same file modified | Higher priority team wins, other rebases |
| API signature change | Backend defines, Frontend adapts |
| Database schema change | Infra defines, Backend adapts |
| Type definition conflict | Create shared types in separate file |

### Failure Rollback

If a module fails:

1. Mark task as blocked
2. Post to communication.md
3. Other teams continue if not dependent
4. Assign fix task to appropriate team

### Dependency Coordination

1. Define interfaces BEFORE implementation
2. Use mock responses during development
3. Contract testing before integration

## Microsoft Code Standards

Follow standards in `references/microsoft-code-standards.md`:

- All code must have unit tests (>80% coverage)
- PR must pass CI/CD checks
- At least one code review approval required
- No direct commits to main branch
- Meaningful commit messages (conventional commits)

## Resources

### scripts/
- `init_parallel_dev.py` - Initialize worktrees and branches
- `communicate.py` - Post messages to shared communication file
- `sync_progress.py` - Sync progress across worktrees
- `run_integration_tests.py` - Run integration tests
- `merge_worktrees.py` - Merge all worktrees in order
- `cleanup_worktrees.py` - Remove worktrees after merge

### references/
- `microsoft-code-standards.md` - Microsoft coding practices
- `api-contract-template.md` - Template for API contracts
- `code-review-checklist.md` - Code review requirements

### assets/
- `pr-template.md` - Pull request template
- `commit-conventions.md` - Commit message format
