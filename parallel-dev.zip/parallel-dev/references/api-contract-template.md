# API Contract Template

Use this template to define API contracts BEFORE implementation.

## Contract Version: [version]

**Last Updated**: [date]
**Status**: [draft/approved/deprecated]

---

## Endpoint: [METHOD] /api/[path]

### Description
[What this endpoint does]

### Authentication
- [ ] Public (no auth required)
- [ ] User (JWT token required)
- [ ] Admin (admin role required)

### Request

#### Headers
```
Content-Type: application/json
Authorization: Bearer <token> (if required)
```

#### Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| param1 | string | Yes | Description |
| param2 | integer | No | Description |

#### Request Body
```json
{
  "field1": "string",
  "field2": 123
}
```

### Response

#### Success (200 OK)
```json
{
  "data": {
    "id": 1,
    "name": "example"
  },
  "message": "Success"
}
```

#### Error Responses

**400 Bad Request**
```json
{
  "error": "Invalid parameter",
  "details": "param1 is required"
}
```

**401 Unauthorized**
```json
{
  "error": "Authentication required"
}
```

**500 Internal Server Error**
```json
{
  "error": "Internal server error"
}
```

### Side Effects
- [ ] Creates/updates database records
- [ ] Sends notifications
- [ ] Triggers webhooks
- [ ] Other: ___

### Dependencies
- Requires: [other endpoints/services]
- Used by: [which modules]

---

## Change Log

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0.0 | 2024-01-01 | Initial version | team-name |

---

## Implementation Checklist

- [ ] Backend implementation complete
- [ ] Unit tests written
- [ ] Integration tests passing
- [ ] API documentation updated
- [ ] Frontend integration started
- [ ] Frontend integration complete
