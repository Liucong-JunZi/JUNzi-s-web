# Code Review Checklist

Use this checklist for every code review.

## Functionality
- [ ] Code does what it's supposed to do
- [ ] Edge cases are handled
- [ ] Error handling is appropriate
- [ ] No infinite loops or recursion issues

## Code Quality
- [ ] Code is readable and well-organized
- [ ] Naming is clear and consistent
- [ ] No code duplication (DRY principle)
- [ ] Functions/methods are not too long
- [ ] Comments explain "why", not "what"

## Testing
- [ ] Unit tests cover new functionality
- [ ] Tests are meaningful (not just for coverage)
- [ ] Tests are independent and repeatable
- [ ] Mock/stub usage is appropriate
- [ ] Edge cases are tested

## Security
- [ ] No hardcoded secrets or credentials
- [ ] Input validation is present
- [ ] SQL injection prevented (use ORM)
- [ ] XSS prevention in place
- [ ] Authentication/authorization correct
- [ ] Sensitive data is encrypted

## Performance
- [ ] No N+1 query problems
- [ ] Appropriate use of caching
- [ ] No unnecessary loops or computations
- [ ] Database queries are optimized

## Compatibility
- [ ] Backward compatibility maintained
- [ ] API changes are documented
- [ ] Migration scripts provided (if needed)
- [ ] Environment variables documented

## Documentation
- [ ] README updated (if needed)
- [ ] API documentation updated
- [ ] Complex logic explained
- [ ] Environment setup instructions clear

## Parallel Development Specific
- [ ] No conflicts with other worktrees
- [ ] API contract followed
- [ ] Communication posted for breaking changes
- [ ] Dependencies coordinated

## Review Decision

### Approve
All checks pass, ready to merge.

### Request Changes
Issues found that must be addressed before merge.

### Comment
Suggestions for improvement, but not blocking.

---

## Review Comments Format

When leaving comments, use:

- **MUST**: Blocking issue, must be fixed
- **SHOULD**: Recommended, but optional
- **NIT**: Nitpick, minor style issue

Example:
```
MUST: This query will cause N+1 problem. Use eager loading.
SHOULD: Consider extracting this to a helper function.
NIT: Missing period at end of comment.
```
