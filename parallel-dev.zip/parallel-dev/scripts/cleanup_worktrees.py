#!/usr/bin/env python3
"""
Clean up worktrees after successful merge.

Usage:
    python cleanup_worktrees.py
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output."""
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def get_worktrees():
    """Get list of active worktrees."""
    returncode, stdout, _ = run_command("git worktree list --porcelain")
    if returncode != 0:
        return []

    worktrees = []
    lines = stdout.split("\n")
    current_wt = None
    for line in lines:
        if line.startswith("worktree "):
            current_wt = line.replace("worktree ", "")
        if line.startswith("branch ") and current_wt:
            branch = line.replace("branch ", "")
            worktrees.append({"path": current_wt, "branch": branch})
            current_wt = None

    return worktrees


def remove_worktree(worktree_path):
    """Remove a worktree."""
    print(f"🗑️  Removing worktree: {worktree_path}")

    returncode, _, stderr = run_command(f"git worktree remove {worktree_path}")
    if returncode != 0:
        # Force remove if needed
        returncode, _, stderr = run_command(f"git worktree remove --force {worktree_path}")
        if returncode != 0:
            print(f"❌ Failed to remove: {stderr}")
            return False

    print(f"✅ Removed: {worktree_path}")
    return True


def delete_branch(branch_name):
    """Delete a merged branch."""
    print(f"🗑️  Deleting branch: {branch_name}")

    returncode, _, stderr = run_command(f"git branch -d {branch_name}")
    if returncode != 0:
        print(f"⚠️  Could not delete branch: {stderr}")
        return False

    print(f"✅ Deleted branch: {branch_name}")
    return True


def cleanup_communication():
    """Archive and remove communication file."""
    comm_file = Path(".parallel-dev/communication.md")

    if comm_file.exists():
        # Archive
        archive_dir = Path(".parallel-dev/archive")
        archive_dir.mkdir(exist_ok=True)

        import shutil
        from datetime import datetime

        archive_name = f"communication_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        shutil.move(str(comm_file), str(archive_dir / archive_name))

        print(f"📦 Archived communication file to {archive_dir / archive_name}")


def main():
    parser = argparse.ArgumentParser(description="Clean up worktrees")
    parser.add_argument("--keep-branches", action="store_true", help="Keep branches after removing worktrees")
    parser.add_argument("--keep-comm", action="store_true", help="Keep communication file")
    parser.add_argument("--force", action="store_true", help="Force removal even with uncommitted changes")
    args = parser.parse_args()

    print("🧹 Cleaning up worktrees...\n")

    worktrees = get_worktrees()

    if not worktrees:
        print("⚠️  No worktrees to clean up")
        return

    # Remove worktrees
    removed_wt = []
    for wt in worktrees:
        if remove_worktree(wt["path"]):
            removed_wt.append(wt)

    # Delete branches
    if not args.keep_branches:
        print("\n🗑️  Deleting merged branches...\n")
        for wt in removed_wt:
            delete_branch(wt["branch"])

    # Cleanup communication
    if not args.keep_comm:
        cleanup_communication()

    # Summary
    print(f"\n📊 Cleanup Summary:\n")
    print(f"  🗑️  Removed {len(removed_wt)} worktrees")
    if not args.keep_branches:
        print(f"  🗑️  Deleted {len(removed_wt)} branches")
    if not args.keep_comm:
        print(f"  📦 Archived communication file")

    print("\n✅ Cleanup complete!")


if __name__ == "__main__":
    main()
