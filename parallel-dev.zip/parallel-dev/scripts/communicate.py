#!/usr/bin/env python3
"""
Post messages to shared communication file.

Usage:
    python communicate.py --from backend-team --to frontend-team --message "API ready"
"""

import argparse
from datetime import datetime
from pathlib import Path


def post_message(from_team, to_team, message, action_items=None):
    """Post a message to the communication file."""
    comm_file = Path(".parallel-dev/communication.md")

    if not comm_file.exists():
        print("❌ Communication file not found. Run init_parallel_dev.py first.")
        return False

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    msg_block = f"""
## [{timestamp}] From: {from_team} → To: {to_team}

### Message
{message}
"""

    if action_items:
        msg_block += "\n### Action Required\n"
        for item in action_items:
            msg_block += f"- [ ] {item}\n"

    msg_block += "\n---\n"

    # Append to file
    with open(comm_file, "a") as f:
        f.write(msg_block)

    print(f"✅ Message posted: {from_team} → {to_team}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Post message to communication file")
    parser.add_argument("--from", dest="from_team", required=True, help="Sender team name")
    parser.add_argument("--to", dest="to_team", required=True, help="Recipient team name")
    parser.add_argument("--message", required=True, help="Message content")
    parser.add_argument("--action", nargs="*", help="Action items")
    args = parser.parse_args()

    post_message(args.from_team, args.to_team, args.message, args.action)


if __name__ == "__main__":
    main()
