#!/usr/bin/env python3
"""
Initialize parallel development worktrees.

Usage:
    python init_parallel_dev.py --modules "frontend" "backend" "infra"
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output."""
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def create_worktree(module_name, base_branch="main"):
    """Create a worktree for a module."""
    worktree_path = f".worktrees/{module_name}"
    branch_name = f"feature/{module_name}"

    # Check if worktree already exists
    if os.path.exists(worktree_path):
        print(f"⚠️  Worktree already exists: {worktree_path}")
        return False

    # Create worktree with new branch
    cmd = f"git worktree add -b {branch_name} {worktree_path} {base_branch}"
    returncode, stdout, stderr = run_command(cmd)

    if returncode != 0:
        print(f"❌ Failed to create worktree: {stderr}")
        return False

    print(f"✅ Created worktree: {worktree_path} (branch: {branch_name})")
    return True


def create_communication_file():
    """Create shared communication file."""
    comm_dir = Path(".parallel-dev")
    comm_dir.mkdir(exist_ok=True)

    comm_file = comm_dir / "communication.md"
    if not comm_file.exists():
        comm_file.write_text("""# Parallel Development Communication

This file is used for inter-team communication during parallel development.

---

## Communication Log

""")
        print("✅ Created communication file: .parallel-dev/communication.md")
    else:
        print("⚠️  Communication file already exists")


def main():
    parser = argparse.ArgumentParser(description="Initialize parallel development worktrees")
    parser.add_argument("--modules", nargs="+", required=True, help="Module names to create worktrees for")
    parser.add_argument("--base-branch", default="main", help="Base branch to create from")
    args = parser.parse_args()

    # Check if we're in a git repo
    returncode, _, _ = run_command("git rev-parse --git-dir")
    if returncode != 0:
        print("❌ Not in a git repository")
        sys.exit(1)

    # Create worktrees
    print(f"\n🚀 Initializing parallel development for modules: {', '.join(args.modules)}\n")

    success_count = 0
    for module in args.modules:
        if create_worktree(module, args.base_branch):
            success_count += 1

    # Create communication file
    create_communication_file()

    # Summary
    print(f"\n📊 Summary: {success_count}/{len(args.modules)} worktrees created")
    print("\nNext steps:")
    print("1. Create team with TeamCreate")
    print("2. Spawn agents for each worktree")
    print("3. Distribute tasks using TaskUpdate")

    # List worktrees
    print("\n📁 Active worktrees:")
    run_command("git worktree list")


if __name__ == "__main__":
    main()
