#!/usr/bin/env python3
"""
Merge worktrees in specified order.

Usage:
    python merge_worktrees.py --order infra backend frontend
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output."""
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def get_worktrees():
    """Get list of active worktrees with their branches."""
    returncode, stdout, _ = run_command("git worktree list --porcelain")
    if returncode != 0:
        return []

    worktrees = []
    lines = stdout.split("\n")
    current_wt = None
    for line in lines:
        if line.startswith("worktree "):
            current_wt = line.replace("worktree ", "")
        if line.startswith("branch ") and current_wt:
            branch = line.replace("branch ", "")
            worktrees.append({"path": current_wt, "branch": branch})
            current_wt = None

    return worktrees


def merge_branch(branch_name, target_branch="main"):
    """Merge a branch into target."""
    print(f"\n🔀 Merging {branch_name} into {target_branch}...")

    # Checkout target
    returncode, _, stderr = run_command(f"git checkout {target_branch}")
    if returncode != 0:
        print(f"❌ Failed to checkout {target_branch}: {stderr}")
        return False

    # Merge
    returncode, _, stderr = run_command(f"git merge {branch_name} --no-ff")
    if returncode != 0:
        print(f"❌ Merge failed: {stderr}")
        print("💡 Resolve conflicts manually and commit")
        return False

    print(f"✅ Merged {branch_name}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Merge worktrees in order")
    parser.add_argument("--order", nargs="+", required=True, help="Merge order (module names)")
    parser.add_argument("--target", default="main", help="Target branch to merge into")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be merged")
    args = parser.parse_args()

    print(f"🚀 Merging worktrees in order: {' → '.join(args.order)}\n")

    worktrees = get_worktrees()
    wt_map = {wt["branch"].replace("feature/", ""): wt for wt in worktrees}

    if args.dry_run:
        print("Dry run - would merge:\n")
        for module in args.order:
            if module in wt_map:
                print(f"  {module} ({wt_map[module]['branch']})")
            else:
                print(f"  ⚠️  {module} - not found")
        return

    # Merge in order
    merged = []
    failed = []

    for module in args.order:
        if module not in wt_map:
            print(f"⚠️  Worktree not found: {module}")
            continue

        branch = wt_map[module]["branch"]
        if merge_branch(branch, args.target):
            merged.append(module)
        else:
            failed.append(module)
            break  # Stop on first failure

    # Summary
    print(f"\n📊 Merge Summary:\n")
    print(f"  ✅ Merged: {', '.join(merged) if merged else 'none'}")
    print(f"  ❌ Failed: {', '.join(failed) if failed else 'none'}")

    if failed:
        print("\n💡 Fix merge conflicts and retry")
        sys.exit(1)
    else:
        print("\n✅ All branches merged successfully!")
        print("💡 Run cleanup_worktrees.py to remove worktrees")


if __name__ == "__main__":
    main()
