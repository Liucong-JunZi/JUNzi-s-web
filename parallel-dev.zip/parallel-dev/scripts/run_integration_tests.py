#!/usr/bin/env python3
"""
Run integration tests across all worktrees.

Usage:
    python run_integration_tests.py
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output."""
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def run_module_tests(worktree_path, module_name):
    """Run tests for a specific module."""
    print(f"\n🧪 Running tests for: {module_name}")
    print(f"   Path: {worktree_path}\n")

    # Detect test framework
    test_commands = [
        ("npm test", "package.json"),
        ("pnpm test", "package.json"),
        ("go test ./...", "go.mod"),
        ("pytest", "requirements.txt"),
        ("cargo test", "Cargo.toml"),
    ]

    for cmd, indicator in test_commands:
        if os.path.exists(os.path.join(worktree_path, indicator)):
            print(f"   Running: {cmd}")
            returncode, stdout, stderr = run_command(cmd, cwd=worktree_path)

            if returncode == 0:
                print(f"   ✅ Tests passed")
                return True
            else:
                print(f"   ❌ Tests failed")
                print(stderr)
                return False

    print(f"   ⚠️  No test framework detected")
    return None


def run_integration_tests():
    """Run integration tests after merging."""
    print("\n🔗 Running integration tests...\n")

    # Check for integration test file
    integration_test = Path("tests/integration")
    if integration_test.exists():
        returncode, stdout, stderr = run_command("pytest tests/integration -v")
        if returncode == 0:
            print("✅ Integration tests passed")
            return True
        else:
            print("❌ Integration tests failed")
            print(stderr)
            return False
    else:
        print("⚠️  No integration tests found")
        return None


def main():
    parser = argparse.ArgumentParser(description="Run integration tests")
    parser.add_argument("--skip-unit", action="store_true", help="Skip unit tests")
    args = parser.parse_args()

    print("🚀 Running test suite...\n")

    # Get worktrees
    returncode, stdout, _ = run_command("git worktree list --porcelain")
    if returncode != 0:
        print("❌ Failed to list worktrees")
        sys.exit(1)

    worktrees = []
    lines = stdout.split("\n")
    current_wt = None
    for line in lines:
        if line.startswith("worktree "):
            current_wt = line.replace("worktree ", "")
        if line.startswith("branch ") and current_wt:
            branch = line.replace("branch ", "feature/")
            worktrees.append((current_wt, branch.split("/")[-1]))
            current_wt = None

    # Run module tests
    results = {}
    if not args.skip_unit:
        for wt_path, module_name in worktrees:
            result = run_module_tests(wt_path, module_name)
            results[module_name] = result

    # Summary
    print("\n📊 Test Summary:\n")
    for module, result in results.items():
        status = "✅" if result else ("⚠️" if result is None else "❌")
        print(f"  {status} {module}")

    # Run integration tests
    integration_result = run_integration_tests()

    # Overall status
    all_passed = all(r in [True, None] for r in results.values()) and integration_result in [True, None]

    if all_passed:
        print("\n✅ All tests passed! Ready for merge.")
    else:
        print("\n❌ Some tests failed. Fix before merging.")
        sys.exit(1)


if __name__ == "__main__":
    main()
