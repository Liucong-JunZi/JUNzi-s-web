#!/usr/bin/env python3
"""
Synchronize progress across worktrees.

Usage:
    python sync_progress.py
"""

import os
import subprocess
from pathlib import Path


def run_command(cmd, cwd=None):
    """Run a shell command and return output."""
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def get_worktrees():
    """Get list of active worktrees."""
    returncode, stdout, _ = run_command("git worktree list --porcelain")
    if returncode != 0:
        return []

    worktrees = []
    lines = stdout.split("\n")
    for line in lines:
        if line.startswith("worktree "):
            worktrees.append(line.replace("worktree ", ""))
    return worktrees


def get_branch_status(worktree_path):
    """Get branch and commit info for a worktree."""
    returncode, branch, _ = run_command("git branch --show-current", cwd=worktree_path)
    returncode, commits, _ = run_command("git log --oneline -5", cwd=worktree_path)

    return {
        "path": worktree_path,
        "branch": branch,
        "recent_commits": commits.split("\n") if commits else []
    }


def check_conflicts():
    """Check for potential conflicts between worktrees."""
    conflicts = []

    worktrees = get_worktrees()
    modified_files = {}

    for wt in worktrees:
        returncode, stdout, _ = run_command("git diff --name-only HEAD", cwd=wt)
        if stdout:
            files = set(stdout.split("\n"))
            modified_files[wt] = files

    # Check for overlapping modified files
    wt_list = list(modified_files.keys())
    for i, wt1 in enumerate(wt_list):
        for wt2 in wt_list[i+1:]:
            overlap = modified_files[wt1] & modified_files[wt2]
            if overlap:
                conflicts.append({
                    "worktree1": wt1,
                    "worktree2": wt2,
                    "files": overlap
                })

    return conflicts


def main():
    print("🔄 Syncing progress across worktrees...\n")

    worktrees = get_worktrees()

    if not worktrees:
        print("⚠️  No worktrees found")
        return

    print("📁 Worktree Status:\n")

    for wt in worktrees:
        status = get_branch_status(wt)
        print(f"  {status['branch']}")
        print(f"    Path: {status['path']}")
        if status['recent_commits']:
            print(f"    Recent: {status['recent_commits'][0]}")
        print()

    # Check for conflicts
    print("🔍 Checking for conflicts...\n")
    conflicts = check_conflicts()

    if conflicts:
        print("⚠️  Potential conflicts detected:\n")
        for conflict in conflicts:
            print(f"  {conflict['worktree1']} ↔ {conflict['worktree2']}")
            for f in conflict['files']:
                print(f"    - {f}")
            print()
    else:
        print("✅ No conflicts detected")

    print("\n💡 Recommendations:")
    print("  - Review communication.md for pending messages")
    print("  - Run integration tests before merge")
    print("  - Coordinate API changes with dependent teams")


if __name__ == "__main__":
    main()
